package heaps;
import org.junit.jupiter.api.Test;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.junit.jupiter.api.Assertions.assertTrue;

public class TripletTest {
    @Test
    void testNPE(){
        var triplet1 = new HeapQueue.Triplet<Integer,Object>(1,1L,new Object());
        assertThrows(NullPointerException.class,()->{
            triplet1.compareTo(null);
        });
    }
    @Test
    void test_multiple_int_cases(){
        HeapQueue.Triplet<Integer,Object>[] triplets1 = new HeapQueue.Triplet[7];
        HeapQueue.Triplet<Integer,Object>[] triplets2 = new HeapQueue.Triplet[7];

        triplets1[0] = new HeapQueue.Triplet<Integer,Object>(1,1L,new Object());
        triplets1[1] = new HeapQueue.Triplet<Integer,Object>(-2,2L,new Object());
        triplets1[2] = new HeapQueue.Triplet<Integer,Object>(null,3L,new Object());
        triplets1[3] = new HeapQueue.Triplet<Integer,Object>(null,4L,new Object());
        triplets1[4] = new HeapQueue.Triplet<Integer,Object>(null,5L,new Object());
        triplets1[5] = new HeapQueue.Triplet<Integer,Object>(1,6L,new Object());
        triplets1[6] = new HeapQueue.Triplet<Integer,Object>(1,6L,new Object());

        triplets2[0] = new HeapQueue.Triplet<Integer,Object>(1,6L,new Object());
        triplets2[1] = new HeapQueue.Triplet<Integer,Object>(4,7L,new Object());
        triplets2[2] = new HeapQueue.Triplet<Integer,Object>(3,8L,new Object());
        triplets2[3] = new HeapQueue.Triplet<Integer,Object>(null,9L,new Object());
        triplets2[4] = new HeapQueue.Triplet<Integer,Object>(null,3L,new Object());
        triplets2[5] = new HeapQueue.Triplet<Integer,Object>(1,13L,new Object());
        triplets2[6] = new HeapQueue.Triplet<Integer,Object>(null,3L,new Object());

        int[] expectedResults = {1,-1,-1,1,-1,1,1};

        for(int i=0 ; i<expectedResults.length ; i++){
            tripletsComparedShouldEqualExpectedResult(triplets1[i],triplets2[i],expectedResults[i]);
        }
    }

    @Test
    void test_multiple_string_cases() {
        HeapQueue.Triplet<String, Object>[] triplets1 = new HeapQueue.Triplet[7];
        HeapQueue.Triplet<String, Object>[] triplets2 = new HeapQueue.Triplet[7];

        triplets1[0] = new HeapQueue.Triplet<>("apple", 1L, new Object());
        triplets1[1] = new HeapQueue.Triplet<>("banana", 2L, new Object());
        triplets1[2] = new HeapQueue.Triplet<>(null, 3L, new Object());
        triplets1[3] = new HeapQueue.Triplet<>(null, 4L, new Object());
        triplets1[4] = new HeapQueue.Triplet<>(null, 5L, new Object());
        triplets1[5] = new HeapQueue.Triplet<>("apple", 6L, new Object());
        triplets1[6] = new HeapQueue.Triplet<>("apple", 6L, new Object());

        triplets2[0] = new HeapQueue.Triplet<>("apple", 6L, new Object());
        triplets2[1] = new HeapQueue.Triplet<>("orange", 7L, new Object());
        triplets2[2] = new HeapQueue.Triplet<>("pear", 8L, new Object());
        triplets2[3] = new HeapQueue.Triplet<>(null, 9L, new Object());
        triplets2[4] = new HeapQueue.Triplet<>(null, 3L, new Object());
        triplets2[5] = new HeapQueue.Triplet<>("banana", 13L, new Object());
        triplets2[6] = new HeapQueue.Triplet<>(null, 3L, new Object());

        int[] expectedResults = {1, -1, -1, 1, -1, -1, 1};

        for (int i = 0; i < expectedResults.length; i++) {
            tripletsComparedShouldEqualExpectedResult(triplets1[i], triplets2[i], expectedResults[i]);
        }
    }

    @Test
    private <P extends Comparable<? super P>, V> void tripletsComparedShouldEqualExpectedResult(HeapQueue.Triplet<P, V> triplet1, HeapQueue.Triplet<P, V> triplet2, int expectedResult) {
        if (expectedResult < 0) {
            assertTrue(triplet1.compareTo(triplet2) < 0);
        } else {
            assertTrue(triplet1.compareTo(triplet2) > 0);
        }
    }
}
