package heaps;
import org.junit.jupiter.api.Test;

import java.util.NoSuchElementException;
import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertThrows;

public class HeapQueueTest {
    //Empty Heap
    @Test
    public void emptyHeapQueueThrowsNSEEAfterUsingElement(){
        var empty = new HeapQueue();
        assertThrows(NoSuchElementException.class,()->{
            empty.element();
        });
    }
    @Test
    public void emptyHeapQueueSizeEquals0(){
        var empty = new HeapQueue();
        assertEquals(0,empty.size());
    }
    @Test
    public void emptyHeapQueueRemoveThrowsNSEE(){
        var empty = new HeapQueue();
        assertThrows(NoSuchElementException.class,()->{
            empty.element();
        });
    }

    //One element Heaps
    @Test
    public void AddOneElementToEmptyHeapHasSize1(){
        var one = new HeapQueue<Integer,Integer>();
        one.add(1,1);
        assertEquals(1,one.size());
    };
    @Test
    public void OneElementHeapReturnsFirstElement(){
        var one = new HeapQueue<Integer,Integer>();
        one.add(1,5);
        assertEquals(5,one.element());
    };
    @Test
    public void RemoveOneElementHeapReturnsValueAndIsEmpty(){
        var one = new HeapQueue<Integer,Integer>();
        one.add(1,5);
        assertEquals(5,one.remove());
        assertEquals(0,one.size());
    };
    @Test
    public void TwoRemoveInOneElementHeapThrowsNSEE(){
        var one = new HeapQueue<Integer,Integer>();
        one.add(1,5);
        one.remove();
        assertThrows(NoSuchElementException.class,()->{
            one.remove();
        });
    };

    //Two Elements Heap
    @Test
    public void TwoAddOneElementShouldReturnFirstElementValue(){
        var two = new HeapQueue<Integer,Integer>();
        two.add(1,5);
        two.add(1,10);
        assertEquals(5,two.element());
    }

    @Test
    public void TwoAddOneElementShouldReturnSecondElementValue(){
        var two = new HeapQueue<Integer,Integer>();
        two.add(1,5);
        two.add(2,10);
        assertEquals(10,two.element());
    }

    @Test
    public void TwoAddOneRemoveShouldReturnFirstElementValueAndElementTheSecondOne(){
        var two = new HeapQueue<Integer,Integer>();
        two.add(2,10);
        two.add(1,5);
        assertEquals(10,two.remove());
        assertEquals(5,two.element());
    }

    @Test
    public void TwoAddOneRemoveShouldReturnSecondElementValueAndElementTheFirstOne(){
        var two = new HeapQueue<Integer,Integer>();
        two.add(2,5);
        two.add(5,10);
        assertEquals(10,two.remove());
        assertEquals(5,two.element());
    }

    //Three elements
    @Test
    public void ThreeAddOneElementShouldReturnFirstElementValue(){
        var three = new HeapQueue<Integer,Integer>();
        three.add(1,1);
        three.add(1,2);
        three.add(1,3);
        assertEquals(1,three.element());
    }
    @Test
    public void ThreeAddOneElementShouldReturnSecondElementValue(){
        var three = new HeapQueue<Integer,Integer>();
        three.add(1,1);
        three.add(2,2);
        three.add(1,3);
        assertEquals(2,three.element());
    }
    @Test
    public void ThreeAddThreeRemoveShouldReturnEachElementInSameOrder(){
        var three = new HeapQueue<Integer,Integer>();
        three.add(1,1);
        three.add(1,2);
        three.add(1,3);
        assertEquals(1,three.remove());
        assertEquals(2,three.remove());
        assertEquals(3,three.remove());
    }

    @Test
    public void AllInOne(){
        var all = new HeapQueue<Integer,Integer>();
        all.add(16,1);
        all.add(10,2);
        all.add(14,3);
        all.add(8,4);
        all.add(7,5);
        all.add(9,6);
        all.add(3,7);
        all.add(1,8);
        all.add(4,9);
        all.add(1,10);
        all.add(null,11);
        all.add(null,12);

        assertEquals(1,all.element());
        assertEquals(12,all.size());

        assertEquals(1,all.remove());
        assertEquals(3,all.remove());
        assertEquals(2,all.remove());
        assertEquals(6,all.remove());
        assertEquals(4,all.remove());
        assertEquals(5,all.remove());
        assertEquals(9,all.remove());
        assertEquals(7,all.remove());
        assertEquals(8,all.remove());
        assertEquals(10,all.remove());
        assertEquals(11,all.remove());
        assertEquals(12,all.remove());

        assertThrows(NoSuchElementException.class,()->{
            all.element();
        });
        assertEquals(0,all.size());
    }

}
