package heaps;

/**
 * A priority queue is a queue in which elements are not deleted in order of arrival, but in descending order of priority (the highest priority is deleted first).
 * In the case of elements with same priority, the output order of the elements themselves is the order of arrival; therefore, in addition to saving their priority, We will need to save an arrival timestamp.
 *
 * @param <P> Is the object to represent the priority
 * @param <V> Is the value of that object
 */
public interface PriorityQueue<P extends Comparable<? super P>,V> {
    /**
     * Adds the element with value "value" and priority "priority". A priority that is null will be considered as the lowest priority.
     * @param priority Priority of the element
     * @param value Value of the element
     */
    void add(P priority, V value);

    /**
     * Returns and then removes the element with the highest priority and first order of arrival.
     * @return the element
     * @throws java.util.NoSuchElementException If the queue is empty
     */
    V remove();

    /**
     *
     * @return The value of the element with the highest priority and first order of arrival.
     * @throws java.util.NoSuchElementException If the queue is empty
     */
    V element();

    /**
     * @return The number of elements of the queue
     */
    int size();
}
