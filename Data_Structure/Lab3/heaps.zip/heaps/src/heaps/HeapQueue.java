package heaps;

import java.util.ArrayList;
import java.util.NoSuchElementException;

public class HeapQueue<P extends Comparable<? super P>,V> implements PriorityQueue<P,V>{
    /**
     * ArrayList containing all the Triplets of the heap
     */
    private final ArrayList<Triplet<P,V>> triplets;
    /**
     * Long storing the time of arrival of each triplet inside the heap.
     */
    private long nextTimeStamp;

    /**
     * Static class to define the elements inside the ArrayList. Contains the Priority of that element, the Value and the time of arrival.
     * Implement comparable.
     * @param <P> Priority of the Triplet
     * @param <V> Value of the Triplet
     */
    static class Triplet<P extends Comparable<? super P>,V> implements Comparable<Triplet<P,V>>{
        private final long timeStamp;
        private final P priority;
        private final V value;
        Triplet(P priority,long timeStamp, V value){
            this.timeStamp = timeStamp;
            this.priority = priority;
            this.value = value;
        }

        /**
         * This compareTo has additional functionality with the null, if the Priority element "P" is null this one will have the lowest priority. Also, this function only returns 1 or -1, and does NOT return a 0 which means that two Triplets are equal.
         * See Comparable Interface for more details.
         * @param other the object to be compared.
         * @return 1 if this Triplet has the highest priority than other and -1 otherwise.
         * @throws NullPointerException if the specified object is null
         */
        @Override
        public int compareTo(Triplet<P,V> other){
            if(other == null){
                throw new NullPointerException("Other is null!");
            }
            int priority;
            if(this.priority == null && other.priority==null){
                priority = 0;
            }else if(this.priority==null){
                priority = -1;
            }else if(other.priority==null){
                priority = 1;
            }else{
                priority = this.priority.compareTo(other.priority);
            }

            if(priority == 0){
                priority = -1;
                if(this.timeStamp < other.timeStamp){
                    priority = 1;
                }
            }
            return priority;
        }
    }

    /**
     * Class Constructor initializes the Heap using an ArrayList with the first element as a null.
     */
    public HeapQueue(){
        triplets = new ArrayList<>(1);
        triplets.add(null);
        this.nextTimeStamp = 0L;
    }

    /**
     * Adds the specified value inside the heap considering its priority inside the heap. Adds a new Triplet inside the ArrayList and then calls the method reorderUp, which maintains the Max-Heap structure, see reorderUP for more details.
     * @param priority Priority of the element
     * @param value Value of the element
     */
    @Override
    public void add(P priority, V value){
        Triplet<P, V> triplet = new Triplet<>(priority, this.nextTimeStamp++, value);
        triplets.add(triplet);
        reorderUp(size());
    }

    /**
     * Recursive function to reorder the Heap, checks the object in the specified índex "i" and compares with its parent node, if the child has better priority they will be swapped until the heap is sorted.
     * @param i The index of the object to order.
     */
    private void reorderUp(int i) {
        //Obtain parent index
        int parentIndex = parentIndex(i);
        if(exists(parentIndex)){
            var son = triplets.get(i);
            var father = triplets.get(parentIndex);
            // Compare and swap if condition is met.
            if(son.compareTo(father) > 0){
                swap(i,parentIndex);
                // Recursive call
                reorderUp(parentIndex);
            }
        }
    }

    /**
     * Returns the value with the highest priority in the heap, and then removes it. Calls the function reorderDown to maintain the Max-HeapStructure, see reorderDown method for more information.
     * @return The value of the element with the highest priority.
     */
    @Override
    public V remove(){
        if(isEmpty()){
            throw new NoSuchElementException("Heap is empty");
        }
        var removed = element();
        swap(1,size());
        triplets.removeLast();
        reorderDown(1);
        return removed;
    }

    /**
     * This function checks for the highest priority between the child nodes of the specified index, checks for all possible cases and if one of the children has better priority will be swapped with its father.
     * @param i The index of the element to order.
     */
    private void reorderDown(int i) {
        //Obtain children index.
        int rightIndex = rightIndex(i);
        int leftIndex = leftIndex(i);
        //Obtain the biggest priority Index
        int compareIndex;
        if (exists(rightIndex) && exists(leftIndex)) {
            if (triplets.get(rightIndex).compareTo(triplets.get(leftIndex)) > 0) {
                compareIndex = rightIndex;
            } else {
                compareIndex = leftIndex;
            }
        /*} else if (exists(rightIndex)) { // Since it's an almost-complete binary-tree from left
            compareIndex = rightIndex;*/   // to right there will never be a right child alone.
        } else if (exists(leftIndex)) {
            compareIndex = leftIndex;
        } else {
            return;
        }
        // Checks priorities and execute swap and recall itself
        if (triplets.get(compareIndex).compareTo(triplets.get(i)) > 0) {
            swap(compareIndex, i);
            reorderDown(compareIndex);
        }
    }

    /**
     *
     * @return The element with the highest priority.
     * @throws NoSuchElementException if the heap is empty
     */
    @Override
    public V element(){
        if (isEmpty()) {
            throw new NoSuchElementException("Heap is empty");
        }
        return triplets.get(1).value;
    }

    /**
     * The number of elements will be the size of the internal ArrayList subtracting 1 since the first position will always be null and won't be considered.
     * @return The number of elements in the Heap.
     */
    @Override
    public int size(){
        return triplets.size() - 1;
    }

    /**
     * Checks if the Heap is empty
     * @return True if its empty false otherwise.
     */
    private boolean isEmpty(){
        return size() == 0;
    }

    /**
     * @param i The child index
     * @return Returns the parent's index.
     */
    static int parentIndex(int i) {
        return i/2;
    }

    /**
     * @param i Parent Index
     * @return The left's child index.
     */
    static int leftIndex(int i) {
        return i*2;
    }

    /**
     * @param i Parent Index
     * @return The right's child index.
     */
     static int rightIndex(int i) {
        return i*2+1;
    }

    /**
     * @param index The index of the element to check.
     * @return True if the index is inside the Heap.
     */
    private boolean exists(int index) {
        return 1 <= index && index <= size();
    }

    /**
     * Swaps position between the two objects specified in their indexes.
     * @param i The first object
     * @param j The second object
     */
    private void swap(int i, int j){
        var temp = triplets.get(i);
        triplets.set(i,triplets.get(j));
        triplets.set(j,temp);
    }

}
