package trees;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;

abstract class AbstractLinkedBinaryTreeTest {
    final static LinkedBinaryTree<Integer> empty = new LinkedBinaryTree<>();
    final LinkedBinaryTree<Integer> tree =
            new LinkedBinaryTree<>(
                    new LinkedBinaryTree<>(null, 2, new LinkedBinaryTree<>(null, 4, null)),
                    1,
                    new LinkedBinaryTree<>(new LinkedBinaryTree<>(null, 5, null), 3, null)
            );

    /*
     *                  root
     *             /           \
     *        left               right
     *       /    \            /     \
     * leftLeft  leftRight rightLeft rightRight
     */

    final LinkedBinaryTree<String> complete =
            new LinkedBinaryTree<>(
                    new LinkedBinaryTree<>(
                            new LinkedBinaryTree<>(null,"leftLeft",null),
                            "left",
                            new LinkedBinaryTree<>(null,"leftRight",null)),
                    "root",
                    new LinkedBinaryTree<>(
                            new LinkedBinaryTree<>(null,"rightLeft",null),
                            "right",
                            new LinkedBinaryTree<>(null,"rightRight",null)));

    /*          root
     *         /    \
     *      left    right
     */
    final LinkedBinaryTree<String> complete2 = new LinkedBinaryTree<>(
            new LinkedBinaryTree<>(null,"left",null),
            "root",
            new LinkedBinaryTree<>(null,"right",null));

    /*
     *      root
     */

    final LinkedBinaryTree<String> root = new LinkedBinaryTree<>(null,"one",null);

    /*
     *      root
     *     /
     *   left
     */
    final LinkedBinaryTree<String> rootLeft = new LinkedBinaryTree<>(
            new LinkedBinaryTree<>(null,"left",null), "root", null);
    /*
     *      root
     *          \
     *          right
     */
    final LinkedBinaryTree<String> rootRight = new LinkedBinaryTree<>(null, "root", new LinkedBinaryTree<>(null,"right",null));

    /*
     *      root
     *     /
     *   left
     *   /
     *  left2
     */
    final LinkedBinaryTree<String> rootLeftLeft = new LinkedBinaryTree<>(
            new LinkedBinaryTree<>(new LinkedBinaryTree<>(null,"left2",null),"left",null), "root", null);
    /*
     *      root
     *     /
     *   left
     *      \
     *      right
     */
    final LinkedBinaryTree<String> rootLeftRight = new LinkedBinaryTree<>(
            new LinkedBinaryTree<>(null,"left",
                    new LinkedBinaryTree<>(null,"right",null)),"root",null);
    /*
     *          root
     *        /
     *      left
     *          \
     *           right
     *         /
     *       left2
     *          \
     *          right2
     *          /
     *       left3
     *
     */
    final LinkedBinaryTree<String> zigZag = new LinkedBinaryTree<>(
            new LinkedBinaryTree<>(null,"left",
                    new LinkedBinaryTree<>(
                            new LinkedBinaryTree<>(null,"left2",
                                    new LinkedBinaryTree<>(
                                            new LinkedBinaryTree<>(null,"left3",null),"right2",null)),"right",null)),"root",null);

    /*
     *          root
     *        /
     *      left
     *          \
     *          right
     *              \
     *              right2
     *                  \
     *                  right3
     */
    final LinkedBinaryTree<String> rootLeftRightRight = new LinkedBinaryTree<>(
            new LinkedBinaryTree<>(null,"left",
                    new LinkedBinaryTree<>(null,"right",
                            new LinkedBinaryTree<>(null,"right2",
                                    new LinkedBinaryTree<>(null,"right3",null)))),"root",null);


    // Utility function to simplify tests on iterators
    static <E> List<E> iterate(Iterator<E> it) {
        var list = new ArrayList<E>();
        while (it.hasNext()) {
            list.add(it.next());
        }
        return list;
    }
}
