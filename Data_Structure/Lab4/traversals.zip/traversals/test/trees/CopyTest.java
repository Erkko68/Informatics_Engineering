package trees;

import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;

import java.util.List;

import static org.junit.jupiter.api.Assertions.*;

class CopyTest extends AbstractLinkedBinaryTreeTest {

    @Test
    @DisplayName("Copy empty tree should return empty tree")
    void empty(){
        assertEquals(empty,new LinkedBinaryTree<>(empty));
    }

    @Test
    @DisplayName("Tree copy with only root should return tree with only root and share element reference of mutable object")
    void rootSet() {
        var tree = new LinkedBinaryTree<>(null,new StringBuilder("Hello"),null);
        var copy = new LinkedBinaryTree<>(tree);
        tree.root().append(" world");
        assertSame(tree.root(), copy.root());
    }

    @Test
    @DisplayName("Tree copy with only root should return tree with only root and immutable object should not be updated")
    void rootSet2() {
        var tree = new LinkedBinaryTree<>(null,1,null);
        var copy = new LinkedBinaryTree<>(tree);
        tree.setRoot(2);
        assertEquals(1,copy.root());
    }

    @Test
    @DisplayName("right child tree copy should have element updated after original is modified")
    void rootSet3() {
        var tree = new LinkedBinaryTree<>(null,new StringBuilder("Hello"),new LinkedBinaryTree<>(null,new StringBuilder("right"),null));
        var copy = new LinkedBinaryTree<>(tree.right());
        tree.right().root().append("modified");
        assertEquals(tree.right().root(),copy.root());
    }

    //Tests Using Iterators

    @Test
    @DisplayName("Left child copy should not have next using inOrder iterator")
    void inOrderNext(){
        // left
        var copy = new LinkedBinaryTree<>(complete2.left());

        var it = complete2.inOrderIterator();
        var itCopy = copy.inOrderIterator();

        itCopy.next(); //left
        assertFalse(itCopy.hasNext());

        assertTrue(it.hasNext());
        assertEquals("left",it.next());  //left
        assertTrue(it.hasNext());
        assertEquals("root",it.next()); //root
        assertTrue(it.hasNext());
        assertEquals("right",it.next()); //right
        assertFalse(it.hasNext());
    }

    @Test
    @DisplayName("Left child copy should return expected values after inOrderIteration")
    void inOrderIteration(){
        var copy = new LinkedBinaryTree<>(complete.left());
        var expected = List.of("leftLeft","left","leftRight");
        assertEquals(expected,iterate(copy.inOrderIterator()));

    }

    @Test
    @DisplayName("Left child copy should not have next using levelOrder iterator")
    void levelOrderNext(){
        // left
        var copy = new LinkedBinaryTree<>(complete2.left());

        var it = complete2.levelOrderIterator();
        var itCopy = copy.levelOrderIterator();

        itCopy.next(); //left
        assertFalse(itCopy.hasNext());

        assertTrue(it.hasNext());
        assertEquals("root",it.next());  //left
        assertTrue(it.hasNext());
        assertEquals("left",it.next()); //root
        assertTrue(it.hasNext());
        assertEquals("right",it.next()); //right
        assertFalse(it.hasNext());
    }

    @Test
    @DisplayName("Left child copy should return expected values after levelOrderIteration")
    void levelOrderIteration(){
        var copy = new LinkedBinaryTree<>(complete.left());
        var expected = List.of("left","leftLeft","leftRight");
        assertEquals(expected,iterate(copy.levelOrderIterator()));

    }





}
