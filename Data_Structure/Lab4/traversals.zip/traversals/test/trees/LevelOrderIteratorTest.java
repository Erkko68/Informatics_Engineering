package trees;

import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;
import java.util.List;
import java.util.NoSuchElementException;

import static org.junit.jupiter.api.Assertions.*;

class LevelOrderIteratorTest extends AbstractLinkedBinaryTreeTest {

    // EMPTY TREES
    @Test
    @DisplayName("empty tree should return NSEE after using next")
    void empty1(){
        var it = empty.levelOrderIterator();
        assertThrows(NoSuchElementException.class,()->{
            it.next();
        });
    }

    @Test
    @DisplayName("empty tree should return ISE after using set")
    void empty2(){
        var it = empty.levelOrderIterator();
        assertThrows(IllegalStateException.class,()->{
            it.set(1);
        });
    }

    @Test
    @DisplayName("hasNext on empty tree should return false")
    void empty3(){
        var it = empty.levelOrderIterator();
        assertFalse(it.hasNext());
    }

    // ONE ELEMENT TREES
    @Test
    @DisplayName("one element tree should return that element after next")
    void one1(){
        var it = root.levelOrderIterator();
        assertEquals("one",it.next());
    }

    @Test
    @DisplayName("one element tree should have root updated after set")
    void one2(){
        var it = root.levelOrderIterator();
        assertThrows(IllegalStateException.class,()->{
            it.set("I can't be set yet");
        });
        assertEquals("one",it.next());
        it.set("I should be set");
        assertEquals("I should be set",root.root());
    }

    //NON-EMPTY TREE ITERATION TEST
    @Test
    @DisplayName("root with left child should return root then left")
    void levelOrder(){
        var expected = List.of("root", "left");
        assertEquals(expected, iterate(rootLeft.levelOrderIterator()));
    }

    @Test
    @DisplayName("root with right child should return root then right")
    void levelOrder1(){
        var expected = List.of("root", "right");
        assertEquals(expected, iterate(rootRight.levelOrderIterator()));
    }

    @Test
    @DisplayName("root with two left child should return root, left, left2")
    void levelOrder2(){
        var expected = List.of("root", "left", "left2");
        assertEquals(expected, iterate(rootLeftLeft.levelOrderIterator()));
    }

    @Test
    @DisplayName("root with left and left with right should return root,left and right")
    void levelOrder3(){
        var expected = List.of("root", "left", "right");
        assertEquals(expected, iterate(rootLeftRight.levelOrderIterator()));
    }

    @Test
    @DisplayName("zig-zag like tree should return correct list")
    void levelOrder4(){
        var expected = List.of("root", "left", "right","left2","right2","left3");
        assertEquals(expected, iterate(zigZag.levelOrderIterator()));
    }

    @Test
    @DisplayName("Root Left child and multiple right children ")
    void levelOrder5(){
        var expected = List.of("root","left","right","right2","right3");
        assertEquals(expected,iterate(rootLeftRightRight.levelOrderIterator()));
    }
    @Test
    @DisplayName("Level order on complete tree should return each expected levels")
    void levelOrder6(){
        var expected = List.of("root","left","right","leftLeft","leftRight","rightLeft","rightRight");
        assertEquals(expected,iterate(complete.levelOrderIterator()));
    }

    @Test
    @DisplayName("Complete left-subtree should return correct iteration")
    void levelOrder7(){
        var expected = List.of("left","leftLeft","leftRight");
        assertEquals(expected,iterate(complete.left().levelOrderIterator()));
    }

    @Test
    @DisplayName("Complete right-subtree should return correct iteration")
    void levelOrder8(){
        var expected = List.of("right","rightLeft","rightRight");
        assertEquals(expected,iterate(complete.right().levelOrderIterator()));
    }


}