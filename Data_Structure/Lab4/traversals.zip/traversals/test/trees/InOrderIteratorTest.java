package trees;

import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;
import java.util.List;

import java.awt.*;
import java.util.NoSuchElementException;

import static org.junit.jupiter.api.Assertions.*;

class InOrderIteratorTest extends AbstractLinkedBinaryTreeTest {
    // EMPTY TREES
    @Test
    @DisplayName("empty tree should return NSEE after using next")
    void empty1(){
        var it = empty.inOrderIterator();
        assertThrows(NoSuchElementException.class,()->{
            it.next();
        });
    }
    @Test
    @DisplayName("empty tree should return ISE after using set")
    void empty2(){
        var it = empty.inOrderIterator();
        assertThrows(IllegalStateException.class,()->{
            it.set(1);
        });
    }
    @Test
    @DisplayName("hasNext on empty tree should return false")
    void empty3(){
        var it = empty.inOrderIterator();
        assertFalse(it.hasNext());
    }

    // ONE ELEMENT TREES
    @Test
    @DisplayName("one element tree should return that element after next")
    void one1(){
        var it = root.inOrderIterator();
        assertEquals("one",it.next());
    }
    @Test
    @DisplayName("one element tree should have root updated after set")
    void one2(){
        var it = root.inOrderIterator();
        assertThrows(IllegalStateException.class,()->{
            it.set("I can't be set yet");
        });
        assertEquals("one",it.next());
        it.set("I should be set");
        assertEquals("I should be set",root.root());
    }

    //NON-EMPTY TREE ITERATION TEST

    @Test
    @DisplayName("root with left child should return left then root")
    void inorder0(){
        var expected = List.of("left","root");
        assertEquals(expected,iterate(rootLeft.inOrderIterator()));
    }

    @Test
    @DisplayName("root with right child should return root then right")
    void inorder1(){
        var expected = List.of("root","right");
        assertEquals(expected,iterate(rootRight.inOrderIterator()));
    }

    @Test
    @DisplayName("root with two left child should return left2, left then root")
    void inorder2(){
        var expected = List.of("left2","left","root");
        assertEquals(expected,iterate(rootLeftLeft.inOrderIterator()));
    }

    @Test
    @DisplayName("root with left and left with right should return left,right and root")
    void inorder3(){
        var expected = List.of("left","right","root");
        assertEquals(expected,iterate(rootLeftRight.inOrderIterator()));
    }


    @Test
    @DisplayName("zig-zag-like tree should return correct in-order iteration")
    void inorder4(){
        var expected = List.of("left","left2","left3","right2","right","root");
        assertEquals(expected,iterate(zigZag.inOrderIterator()));
    }

    @Test
    @DisplayName("Left child multiple right child children, root should be last in iteration")
    void inorder5(){
        var expected = List.of("left","right","right2","right3","root");
        assertEquals(expected,iterate(rootLeftRightRight.inOrderIterator()));
    }

    @Test
    @DisplayName("iteration in complete binary tree should be equal to expected result")
    void inorder6(){
        var expected = List.of("leftLeft","left","leftRight","root","rightLeft","right","rightRight");
        assertEquals(expected,iterate(complete.inOrderIterator()));
    }

    @Test
    @DisplayName("Complete left-subtree should return expected list")
    void inorder7(){
        var expected = List.of("leftLeft","left","leftRight","root","rightLeft","right","rightRight");
        assertEquals(expected,iterate(complete.left().inOrderIterator()));
    }

    @Test
    @DisplayName("Complete right-subtree should return expected list")
    void inorder8(){
        var expected = List.of("rightLeft","right","rightRight");
        assertEquals(expected,iterate(complete.right().inOrderIterator()));
    }
}
