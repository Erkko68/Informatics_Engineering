package cat.udl.eps.ed.practica2.stack;


import org.junit.jupiter.api.Test;

import java.util.NoSuchElementException;

import static org.junit.jupiter.api.Assertions.*;

class LinkedStackTest {
    // Tests emptyStack
    @Test
    void isEmpty_on_empty_stack_should_return_true(){
        var emptyStack = new LinkedStack<Integer>();
        assertTrue(emptyStack.isEmpty());
    }

    @Test
    void pop_on_empty_stack_should_throw_nse_exception() {
        var emptyStack = new LinkedStack<Integer>();
        assertThrows(NoSuchElementException.class, () -> {
            emptyStack.pop();
        });
    }
    @Test
    void top_on_empty_stack_should_throw_nse_exception(){
        var emptyStack = new LinkedStack<Integer>();
        assertThrows(NoSuchElementException.class,() ->{
            emptyStack.top();
        });
    }
    // Tests stack with one element
    @Test
    void isEmpty_on_stack_with_elements_should_return_false(){
        var oneElementStack = new LinkedStack<Integer>();
        oneElementStack.push(1); // Add element
        assertFalse(oneElementStack.isEmpty());
    }
    @Test
    void pop_on_stack_with_one_element_should_empty_stack() {
        var oneElementStack = new LinkedStack<Integer>();
        oneElementStack.push(1);    //Add element
        oneElementStack.pop();      //Pop element
        assertTrue(oneElementStack.isEmpty());
    }

    @Test
    void top_on_stack_with_one_element_should_return_first_element_and_not_be_empty(){
        var oneElementStack = new LinkedStack<Integer>();
        oneElementStack.push(1);
        assertEquals(1,oneElementStack.top());
        assertFalse(oneElementStack.isEmpty());
    }
    // Tests multiple elements
    @Test
    void top_on_stack_with_elements_should_return_last_element_and_not_be_empty(){
        var elementsStack = new LinkedStack<Integer>();
        elementsStack.push(1);
        elementsStack.push(2);
        assertEquals(2,elementsStack.top());
        assertFalse(elementsStack.isEmpty());
    }
    @Test
    void top_on_stack_with_two_elements_should_return_second_element_and_after_pop_should_return_the_first_element(){
        var elementsStack = new LinkedStack<Integer>();
        elementsStack.push(1);
        elementsStack.push(2);
        assertEquals(2,elementsStack.top());
        elementsStack.pop();
        assertEquals(1,elementsStack.top());

    }
    @Test
    void two_pop_on_stack_with_one_element_should_return_nse_exception(){
        var elementsStack = new LinkedStack<Integer>();
        elementsStack.push(1);
        elementsStack.pop();
        assertThrows(NoSuchElementException.class,() ->{
            elementsStack.pop();
        });
    }
    @Test
    void two_pop_on_stack_with_two_element_should_be_empty(){
        var elementsStack = new LinkedStack<Integer>();
        elementsStack.push(1);
        elementsStack.push(2);
        elementsStack.pop();
        elementsStack.pop();
        assertTrue(elementsStack.isEmpty());
    }

    @Test
    void push_and_pop_different_data_types_should_return_empty_stack() {
        LinkedStack<String> stack = new LinkedStack<>();
        stack.push("Test1");
        stack.push("Test2");
        stack.pop();
        stack.push("Test3");
        stack.pop();
        stack.pop();
        assertTrue(stack.isEmpty());
    }

    @Test
    void push_and_pop_in_loop_should_return_empty_stack() {
        LinkedStack<Integer> stack = new LinkedStack<>();
        for (int i = 1; i <= 50; i++) {
            stack.push(i);
        }
        for (int i = 50; i > 0; i--) {
            stack.pop();
        }
        assertTrue(stack.isEmpty());
    }

    @Test
    void push_pop_and_size_should_return_the_correct_size() {
        LinkedStack<Integer> stack = new LinkedStack<>();
        assertEquals(0, stack.size());
        stack.push(1);
        assertEquals(1, stack.size());
        stack.push(2);
        assertEquals(2, stack.size());
        stack.pop();
        assertEquals(1, stack.size());
        stack.pop();
        assertEquals(0, stack.size());
    }


}
