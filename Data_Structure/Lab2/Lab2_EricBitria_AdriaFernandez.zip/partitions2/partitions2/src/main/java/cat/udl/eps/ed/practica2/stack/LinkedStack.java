package cat.udl.eps.ed.practica2.stack;

import java.util.Deque;
import java.util.LinkedList;
import java.util.NoSuchElementException;

/**
 * A linked list implementation of a stack.
 * Implements the stack interface using linked nodes.
 *
 * @param <E> the type of elements in the stack
 * @see Stack
 */
public class LinkedStack<E> implements Stack<E> {

    /**
     * The Node top will always be the first element of the stack
     */
    private Node<E> top;
    /**
     * Number of elements inside the stack
     */
    private int size;

    /**
     * Constructor of the class:
     * Creates an empty stack
     */
    public LinkedStack() {
        top = null;
        size = 0;
    }

    /**
     * @param elem the element to be added
     * Adds a new node into the stack, if the stack is empty top will be the newest element,
     * otherwise the previous element that was in the top will be the new next element of the top.
     */
    @Override
    public void push(E elem) {
        Node<E> newNode = new Node<>(elem);
        if (isEmpty()) {
            top = newNode;
        } else {
            newNode.next = top;
            top = newNode;
        }
        size++;
    }

    /**
     * Removes the element in the top of the stack
     * First checks if the stack is empty, then the top element
     * will be the next one, and we decrease the size.
     * Note that we don't return the top element, as specified in Stack<>
     * So we should use top() if we want to get the top element and then use pop to remove it.
     */
    @Override
    public void pop() {
        if (isEmpty()) {
            throw new NoSuchElementException("Stack is empty");
        }
        top = top.next;
        size--;
    }

    /**
     * Simply returns the top element of the stack
     * @return top element
     */
    @Override
    public E top() {
        if (isEmpty()) {
            throw new NoSuchElementException("Stack is empty");
        }
        return top.element;
    }

    /**
     * @return true if size equals 0.
     */
    @Override
    public boolean isEmpty() {
        return size == 0;
    }

    /**
     * @return the size of the stack
     * ONLY used for testing
     */
    public int size(){
        return size;
    }

    /**
     * Private static class of LinkedStack,
     * creates the reference to the previous element
     * resulting in a stack behaviour.
     * @param <E>
     */
    private static class Node<E> {
        // Element of the node
        private final E element;
        // Reference to the next element
        private Node<E> next;
        // Node constructor
        public Node(E element) {
            this.element = element;
            this.next = null;
        }
    }
}
